package kz.yatooooo.projects.huqualities.repository;

import kz.yatooooo.projects.huqualities.model.Friend;
import kz.yatooooo.projects.huqualities.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface FriendRepository extends JpaRepository<Friend, Long> {

    List<Friend> findAllBySenderAndAcceptAndSend(User sender,  int accept, int send);
    List<Friend> findAllByHostAndAcceptAndSend(User host,  int accept, int send);
    List<Friend> findAllByHostAndHostAnswered(User host, int hostAnswered);
    List<Friend> findAllBySenderAndHostAnsweredAndSenderReceive(User sender, int hostAnswered, int senderReceive);
    List<Friend> findBySenderAndHost(User sender, User host);
    Friend findAllBySenderAndHostAndSendAndAccept(User sender,User host, int send, int accept);
}
