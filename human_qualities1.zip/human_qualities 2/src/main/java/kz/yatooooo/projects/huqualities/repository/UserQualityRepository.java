package kz.yatooooo.projects.huqualities.repository;

import kz.yatooooo.projects.huqualities.model.Quality;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.model.UserQuality;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserQualityRepository extends JpaRepository<UserQuality, Long> {
    void deleteByUserAndQuality(User u, Quality q);
    UserQuality findById(long id);
    UserQuality findByUserAndQuality(User u, Quality q);
    List<UserQuality> findAllByUser(User u);
}
