package kz.yatooooo.projects.huqualities.service;

import kz.yatooooo.projects.huqualities.model.Quality;

import java.util.List;

public interface QualityService {
    void saveQuality(String name, String description);
    void updateQuality(Long id, String name, String description);
    void deleteQuality(Long id);
    boolean isQualityExist(String title);
    Quality getQualityByName(String title);
    List<Quality>  allQualities();
}
