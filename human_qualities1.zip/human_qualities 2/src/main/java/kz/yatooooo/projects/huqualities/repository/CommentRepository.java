package kz.yatooooo.projects.huqualities.repository;

import kz.yatooooo.projects.huqualities.model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentRepository extends JpaRepository<Comment, Long> {

}
