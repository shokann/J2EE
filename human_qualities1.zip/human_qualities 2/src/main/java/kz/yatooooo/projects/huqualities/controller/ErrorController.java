package kz.yatooooo.projects.huqualities.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ErrorController {
    @GetMapping("/user/page/error")
    public ModelAndView display(@ModelAttribute("message") final String
                                            message){
        ModelAndView modelAndView = new ModelAndView();
        if(!message.equals("") && !message.isEmpty()){
            if(message.equals("type")){
                modelAndView.addObject("message", "Type of file is not " +
                        "valid!");
            }else if(message.equals("size")){
                modelAndView.addObject("message", "Size of file is too big " +
                        "to upload");
            }
        }
        modelAndView.setViewName("user/error");
        return modelAndView;
    }
}
