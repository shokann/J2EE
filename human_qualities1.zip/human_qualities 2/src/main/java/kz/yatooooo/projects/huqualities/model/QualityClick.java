package kz.yatooooo.projects.huqualities.model;

import org.hibernate.mapping.Join;

import javax.persistence.*;

@Entity
public class QualityClick {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long ID;

    @ManyToOne
    @JoinColumn(name = "USER_QUALITY_ID", referencedColumnName = "USER_QUALITY_ID")
    private UserQuality userQuality;

    @ManyToOne
    @JoinColumn(name = "USER_ID", referencedColumnName = "id")
    private User user;
    private double value;


    public QualityClick() {
    }

    public QualityClick(User user, double value) {
        this.user = user;
        this.value = value;
    }

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public UserQuality getUserQuality() {
        return userQuality;
    }

    public void setUserQuality(UserQuality userQuality) {
        this.userQuality = userQuality;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
}
