package kz.yatooooo.projects.huqualities.model;

import java.io.Serializable;

public class UserQualityId implements Serializable {

    private long user;
    private long quality;

    public long getUser() {
        return user;
    }

    public void setUser(long user) {
        this.user = user;
    }

    public long getQuality() {
        return quality;
    }

    public void setQuality(long quality) {
        this.quality = quality;
    }

    public int hashCode() {
        return (int)(user+quality);
    }

    public boolean equals(Object object) {
        if (object instanceof UserQualityId) {
            UserQualityId otherId = (UserQualityId) object;
            return (otherId.user == this.user) && (otherId.quality == this.quality);
        }
        return false;
    }
}
