package kz.yatooooo.projects.huqualities.model;

import javax.persistence.*;

@Entity
public class QualityEvaluation {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long ID;

    @ManyToOne
    @JoinColumn(name = "USER_QUALITY_ID", referencedColumnName = "USER_QUALITY_ID")
    private UserQuality userQuality;
    private double sum = 0;
    private long count = 0;
    private double average = 0;


    public QualityEvaluation() {
    }

    public QualityEvaluation(UserQuality userQuality) {
        this.userQuality = userQuality;
    }

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public UserQuality getUserQuality() {
        return userQuality;
    }

    public void setUserQuality(UserQuality userQuality) {
        this.userQuality = userQuality;
    }

    public double getSum() {
        return sum;
    }

    public void setSum(double sum) {
        this.sum = sum;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }
}
