package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.text.ParseException;

@Controller
public class UserController {
    @Autowired
    private UserServiceImplementation userServiceImplementation;

    @GetMapping("admin/page/users")
    public ModelAndView displayUsers(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("admin/users");
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();

        modelAndView.addObject("users", userServiceImplementation
                .getAllUsersExceptCurrent(currentPrincipalUsername));
        return modelAndView;
    }

    @PostMapping("admin/page/users/update")
    public ModelAndView changeUserValues(@RequestParam(value = "name", required = false)String name,
                                         @RequestParam(value = "surname", required = false) String surname,
                                         @RequestParam(value = "patronymic",
                                                 required = false) String patronymic,
                                         @RequestParam(value = "username",
                                                 required = false)String username,
                                         @RequestParam(value = "email",
                                                 required = false) String email,
                                         @RequestParam(value = "address",
                                                 required = false)String address,
                                         @RequestParam(value = "marital_status", required = false)String maritalStatus,
                                         @RequestParam(value = "gender", required = false) String gender,
                                         @RequestParam(value = "birth_date",
                                                 required = false)String birthDay,
                                         @RequestParam(value = "role",
                                                 required = false)String role,
                                         @RequestParam(value = "id",
                                                 required = false)String userId
    ) throws ParseException {
        ModelAndView modelAndView = new ModelAndView();


        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();

        userServiceImplementation.updateAll(currentPrincipalUsername, Long
                        .parseLong(userId), name, surname,
                patronymic, username, email, address, maritalStatus,gender,
                birthDay, role);

        modelAndView.setViewName("redirect:/admin/page/users");
        return modelAndView;
    }
    @PostMapping("admin/page/users/delete")
    public ModelAndView changeUserValues(@RequestParam(value = "id", required = false)long id){
        ModelAndView modelAndView = new ModelAndView();
        userServiceImplementation.deleteUser(id);
        modelAndView.setViewName("redirect:/admin/page/users");
        return modelAndView;
    }
}
