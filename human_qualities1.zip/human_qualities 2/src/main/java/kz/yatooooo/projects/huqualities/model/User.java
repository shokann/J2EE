package kz.yatooooo.projects.huqualities.model;

import kz.yatooooo.projects.huqualities.operations.JavaOperations;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.sql.Date;
import java.time.Period;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private long id;

    @Column(name = "role")
    private String role;

    @Column(name = "username", unique = true)
    @NotEmpty(message = "please provide an USERNAME")
    private String username;

    @Column(name = "password")
    @Length(min = 8, message = "your PASSWORD must have at least 8 characters")
    @NotEmpty(message = "please provide your PASSWORD")
    private String password;


    @Column(name = "email", unique = true)
    @Email(message = "please provide a valid EMAIL")
    @NotEmpty(message = "please provide an email")
    private String email;

    @Column(name = "name")
    @NotEmpty(message = "please provide your NAME")
    private String name;

    @Column(name = "surname")
    @NotEmpty(message = "please provide your SURNAME")
    private String surname;

    @Column(name = "patronymic")
    private String patronymic;

    @Column(name = "gender")
    private String gender;

    @Column(name = "birth_day")
    private Date birthDay;

    @Column(name = "address")
    private String address;

    @Column(name = "phone")
    private String phone;

    @Column(name = "marital_status")
    private String maritalStatus;

    @Column(name = "citizenship")
    private String citizenship;

    private Date date = new Date(Calendar.getInstance().getTime().getTime());

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<UserQuality> userQualities = new ArrayList<>();

    @OneToMany(mappedBy = "user")
    private List<QualityClick> qualityClicks = new ArrayList<>();

    @OneToMany(mappedBy = "user")
    private List<Photo> photos = new ArrayList<>();

    @OneToMany(mappedBy = "sender")
    private List<Friend> sender = new ArrayList<>();

    @OneToMany(mappedBy = "host")
    private List<Friend> host = new ArrayList<>();

    public User(){}

    public User(String role, String username, String password, String email, String name, String surname, String patronymic, String gender, Date birthDay, String address, String phone, String maritalStatus, String citizenship) {
        this.role = role;
        this.username = username;
        this.password = password;
        this.email = email;
        this.name = name;
        this.surname = surname;
        this.patronymic = patronymic;
        this.gender = gender;
        this.birthDay = birthDay;
        this.address = address;
        this.phone = phone;
        this.maritalStatus = maritalStatus;
        this.citizenship = citizenship;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getUsername() {
        return username;

    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        String userName = JavaOperations.getFirstLetterUppercase(name);
        return userName;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        String userSurname = JavaOperations.getFirstLetterUppercase(surname);
        return userSurname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(String citizenship) {
        this.citizenship = citizenship;
    }

    public List<Photo> getPhotos() {
        return photos;
    }

    public void setPhotos(List<Photo> photos) {
        this.photos = photos;
    }

    public List<UserQuality> getUserQualities() {
        return userQualities;
    }

    public void setUserQualities(List<UserQuality> userQualities) {
        this.userQualities = userQualities;
    }

    public List<QualityClick> getQualityClicks() {
        return qualityClicks;
    }

    public void setQualityClicks(List<QualityClick> qualityClicks) {
        this.qualityClicks = qualityClicks;
    }

    public List<Friend> getSender() {
        return sender;
    }

    public void setSender(List<Friend> sender) {
        this.sender = sender;
    }

    public List<Friend> getHost() {
        return host;
    }

    public void setHost(List<Friend> host) {
        this.host = host;
    }

    public int getAge(){
        if ((birthDay != null) && (JavaOperations.getCurrentDate() != null)) {
            return Period.between(birthDay.toLocalDate(), JavaOperations.getCurrentDate().toLocalDate())
                    .getYears();
        }
        return 0;
    }
}
