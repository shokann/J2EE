package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.repository.UserRepository;
import kz.yatooooo.projects.huqualities.service.SecurityService;
import kz.yatooooo.projects.huqualities.service.UserService;
import kz.yatooooo.projects.huqualities.serviceImplementation.SecurityServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserQualityServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.jws.WebParam;
import javax.validation.Valid;
import java.sql.Date;

@Controller
public class RegistrationController {
    @Autowired
    private UserService userService;
    @Autowired
    private UserQualityServiceImplementation userQualityServiceImplementation;
    @Autowired
    private SecurityServiceImplementation securityServiceImplementation;


    @GetMapping("/page/registration")
    public ModelAndView display(){
        ModelAndView modelAndView = new ModelAndView();
        User user = new User();
        modelAndView.addObject("user", user);
        modelAndView.setViewName("registration");
        return modelAndView;
    }

    @PostMapping("/page/registration/register")
    public ModelAndView register(@Valid User user, BindingResult bindingResult,
                           @RequestParam(value = "repassword", required = false) String repassword){
        ModelAndView modelAndView = new ModelAndView();

        if(userService.isEmailExist(user.getEmail())) bindingResult.rejectValue("email", "error.user","There is already a user registered with the email provided");
        if(userService.isUsernameExist(user.getUsername())) bindingResult.rejectValue("username", "error.user","There is already a user registered with the username provided");
        boolean isPasswordConfirmed = true;
        if(repassword==null || repassword.equals("") || !repassword.equals(user.getPassword())) isPasswordConfirmed = false;

        if (bindingResult.hasErrors() || isPasswordConfirmed==false) {
            if(isPasswordConfirmed==false) modelAndView.addObject("repassword", "password not confirmed");
            modelAndView.setViewName("registration");
        } else {
            userService.saveUser(user);
            try {
                userService.uploadPhoto(user, "default_avatar.png");
            } catch (Exception e) {
                e.printStackTrace();
            }

            securityServiceImplementation.autologin(user.getUsername(), user.getPassword());

            /**
             *
             * Author Akezhan
             * I will be delete
             */
//           userQualityServiceImplementation.addQualityToUser(1,1);


            String role = securityServiceImplementation.getCurrentUserRole();
            if(role.equals("admin")){
                modelAndView.setViewName("redirect:/admin/page/home");
            }else if(role.equals("user")){
                modelAndView.setViewName("redirect:/user/page/home");
            }else{
                modelAndView.setViewName("redirect:/");
            }
        }

        return modelAndView;
    }

}
