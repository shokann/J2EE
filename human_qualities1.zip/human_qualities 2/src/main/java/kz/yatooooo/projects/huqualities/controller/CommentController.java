package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.model.Comment;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.serviceImplementation.CommentServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CommentController {
    @Autowired
    private CommentServiceImplementation commentServiceImplementation;
    @Autowired
    private UserServiceImplementation userServiceImplementation;


    //@PostMapping("/user/page/comment/add/ajax")
    @RequestMapping(value="/user/page/comment/add/ajax",method=RequestMethod.POST, consumes = "application/json", produces = "application/json")
    public @ResponseBody Comment add(@RequestParam String[] data) {

        Comment result = new Comment();
        result.setMessage("message");
        User listener = userServiceImplementation.getUserById( Long.parseLong(data[0], 10));
        User commentator = userServiceImplementation.getCurrentUser();
        result = commentServiceImplementation.add(listener, commentator, data[1]);

        System.out.println(result.getMessage());
        return result;
    }


    @PostMapping("/user/page/comment/add")
    public ModelAndView add(@RequestParam(name = "user_id", required = false)long listener_id, @RequestParam(name = "message", required = false)String message){
        ModelAndView modelAndView = new ModelAndView();

        User listener = userServiceImplementation.getUserById(listener_id);
        User commentator = userServiceImplementation.getCurrentUser();

        if(commentServiceImplementation.add(listener, commentator, message)!=null)
            modelAndView.addObject("message", "Comment successfully added!");
        else
            modelAndView.addObject("message", "Comment not added");

        modelAndView.setViewName("user/page/home");
        return modelAndView;
    }

    @PostMapping("/user/page/comment/change")
    public ModelAndView change(@RequestParam(name = "comment_id", required = false)long comment_id,@RequestParam(name = "message", required = false)String message){
        ModelAndView modelAndView = new ModelAndView();

        if(commentServiceImplementation.change(comment_id, message)!=null)
            modelAndView.addObject("message", "Comment successfully changed!");
        else
            modelAndView.addObject("message", "Comment not changed");

        modelAndView.setViewName("user/page/home");
        return modelAndView;
    }

    @PostMapping("/user/page/comment/delete")
    public ModelAndView delete(@RequestParam(name = "comment_id", required = false)long comment_id){
        ModelAndView modelAndView = new ModelAndView();

        if(commentServiceImplementation.delete(comment_id)==true)
            modelAndView.addObject("message", "Comment successfully deleted!");
        else
            modelAndView.addObject("message", "Comment not deleted");

        modelAndView.setViewName("user/page/home");
        return modelAndView;
    }
}
