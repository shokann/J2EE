package kz.yatooooo.projects.huqualities.serviceImplementation;

import kz.yatooooo.projects.huqualities.model.Friend;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.repository.FriendRepository;
import kz.yatooooo.projects.huqualities.repository.UserRepository;
import kz.yatooooo.projects.huqualities.service.FriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

@Service
public class FriendServiceImplementation implements FriendService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private FriendRepository friendRepository;

    public void send(long hostId){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        User sender = userRepository.findByUsername(currentPrincipalName);
        User host = userRepository.findById(hostId);

        if(sender!=host && !isSendingExist(sender, host)){
            Friend friend = new Friend(sender,host);
            friendRepository.save(friend);
        }
    }

    public boolean isSendingExist(User sender, User host){
        if(friendRepository.findBySenderAndHost(sender, host).size()>0) return true;
        return false;
    }

    public List<User> getAllFriends(){
        List<User> friends = new ArrayList<>();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        User user = userRepository.findByUsername(currentPrincipalName);

        List<Friend> tempFriends = friendRepository.findAllBySenderAndAcceptAndSend(user,1, 1);
        for (Friend f:tempFriends){
            if(f.getHost()!=user) friends.add(f.getHost());
        }

        List<Friend> tempFriends2 = friendRepository.findAllByHostAndAcceptAndSend(user,1, 1);
        for (Friend f:tempFriends2){
            if(f.getSender()!=user) friends.add(f.getSender());
        }

        return friends;
    }

    public List<User> getAllAswers(){
        List<User> answers = new ArrayList<>();

        //get current USER
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        User user = userRepository.findByUsername(currentPrincipalName);


        List<Friend> tempFriends = friendRepository.findAllBySenderAndHostAnsweredAndSenderReceive(user, 1,0);
        for (Friend f:tempFriends){
            if(f.getHost()!=user) answers.add(f.getHost());
        }

        return answers;
    }

    public List<User> getAllApplications(){
        List<User> applications = new ArrayList<>();

        //get current USER
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        User user = userRepository.findByUsername(currentPrincipalName);


        List<Friend> tempFriends = friendRepository.findAllByHostAndHostAnswered(user, 0);
        for (Friend f:tempFriends){
            if(f.getSender()!=user) applications.add(f.getSender());
        }

        return applications;
    }

    public void acceptApplication(long senderId){
        //get current USER
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        User host = userRepository.findByUsername(currentPrincipalName);

        //get sender User
        User sender = userRepository.findById(senderId);

        Friend friend = null;

        if(friendRepository.findBySenderAndHost(sender, host).size()>0) {
            friend = friendRepository.findBySenderAndHost(sender, host).get(0);
            //host accept
            friend.setAccept(1);
            //host answered
            friend.setHostAnswered(1);
            //sender get answer from host
            friend.setSenderReceive(0);

            friendRepository.save(friend);
        }
    }

    public void refuseApplication(long senderId){
        //get current USER
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        User host = userRepository.findByUsername(currentPrincipalName);

        //get sender User
        User sender = userRepository.findById(senderId);

        Friend friend = null;

        if(friendRepository.findBySenderAndHost(sender, host).size()>0) {
            friend = friendRepository.findBySenderAndHost(sender, host).get(0);
            //host accept
            friend.setAccept(0);
            //host answered
            friend.setHostAnswered(1);
            //sender get answer from host
            friend.setSenderReceive(0);

            friendRepository.save(friend);
        }
    }

    public boolean isFriend(long id) {
        //get current USER
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        User host = userRepository.findByUsername(currentPrincipalName);

        //get sender USER
        User sender = userRepository.findById(id);
        Friend f1 = friendRepository.findAllBySenderAndHostAndSendAndAccept(sender, host, 1, 1);
        Friend f2 = friendRepository.findAllBySenderAndHostAndSendAndAccept(host, sender, 1, 1);

        if(f1!=null || f2!=null) return true;
        return false;
    }

    public void deleteFromFriends(long id){
        //get current USER
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        User currentUser = userRepository.findByUsername(currentPrincipalName);

        //get sender USER
        User otherUser = userRepository.findById(id);

        Friend friend1 = null;
        if(friendRepository.findBySenderAndHost(currentUser, otherUser).size()>0) friend1 = friendRepository.findBySenderAndHost(currentUser, otherUser).get(0);
        if(friend1!=null){
            User sender = friend1.getSender();
            User host = friend1.getHost();

            friend1.setSender(host);
            friend1.setHost(sender);
            friend1.setAccept(0);
            friend1.setSenderReceive(-1);
            friend1.setHostAnswered(0);
            friendRepository.save(friend1);
        }

        Friend friend2 = null;
        if(friendRepository.findBySenderAndHost(otherUser, currentUser).size()>0) friend2 = friendRepository.findBySenderAndHost(otherUser, currentUser).get(0);
        if(friend2!=null){
            friend2.setAccept(0);
            friend2.setHostAnswered(0);
            friendRepository.save(friend2);
        }

    }
}
