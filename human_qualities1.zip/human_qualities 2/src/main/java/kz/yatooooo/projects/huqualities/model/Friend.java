package kz.yatooooo.projects.huqualities.model;

import javax.persistence.*;

@Entity
public class Friend {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @ManyToOne
    @JoinColumn(name = "sender", referencedColumnName = "id")
    private User sender;

    @ManyToOne
    @JoinColumn(name = "host", referencedColumnName = "id")
    private User host;

    private int send = 1;
    private int accept = 0;

    private int senderReceive = -1;
    private int hostAnswered = 0;

    public Friend() {
    }

    public Friend(User sender, User host) {
        this.sender = sender;
        this.host = host;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getSender() {
        return sender;
    }

    public void setSender(User sender) {
        this.sender = sender;
    }

    public User getHost() {
        return host;
    }

    public void setHost(User host) {
        this.host = host;
    }


    public int getSend() {
        return send;
    }

    public void setSend(int send) {
        this.send = send;
    }

    public int getAccept() {
        return accept;
    }

    public void setAccept(int accept) {
        this.accept = accept;
    }

    public int getSenderReceive() {
        return senderReceive;
    }

    public void setSenderReceive(int senderReceive) {
        this.senderReceive = senderReceive;
    }

    public int getHostAnswered() {
        return hostAnswered;
    }

    public void setHostAnswered(int hostAnswered) {
        this.hostAnswered = hostAnswered;
    }
}
