package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.model.QualityClick;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.service.UserService;
import kz.yatooooo.projects.huqualities.serviceImplementation.FriendServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class NotificationController {
    @Autowired
    private FriendServiceImplementation friendServiceImplementation;
    @Autowired
    private UserServiceImplementation userServiceImplementation;

    @PostMapping("/user/page/notification/friend/answer/accept")
    public ModelAndView acceptAplication(@RequestParam(value = "id", required = false) long id){

        friendServiceImplementation.acceptApplication(id);
        return new ModelAndView("redirect:/user/page/notifications");
    }

    @PostMapping("/user/page/notification/friend/answer/refuse")
    public ModelAndView refuseApplication(@RequestParam(value = "id", required = false) long id){

        friendServiceImplementation.refuseApplication(id);
        return new ModelAndView("redirect:/user/page/notifications");
    }


    @GetMapping("/user/page/notifications")
    public ModelAndView display(){
        ModelAndView modelAndView = new ModelAndView();

        List<User> applications = friendServiceImplementation.getAllApplications();
        if(applications.size()>0){
            modelAndView.addObject("applications", applications);
        }

        List<User> answers = friendServiceImplementation.getAllAswers();
        if(answers.size()>0){
            modelAndView.addObject("answers", answers);
        }

        List<QualityClick>  qualityClicks = userServiceImplementation.getQualitiyClickNotifications();
        if(qualityClicks.size()>0){
            modelAndView.addObject("clicks", qualityClicks);
        }


        modelAndView.setViewName("user/notification");
        return modelAndView;
    }
}
