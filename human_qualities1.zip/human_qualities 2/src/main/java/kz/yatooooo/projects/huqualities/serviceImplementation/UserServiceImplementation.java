package kz.yatooooo.projects.huqualities.serviceImplementation;

import kz.yatooooo.projects.huqualities.model.*;
import kz.yatooooo.projects.huqualities.operations.JavaOperations;
import kz.yatooooo.projects.huqualities.repository.PhotoRepository;
import kz.yatooooo.projects.huqualities.repository.UserRepository;
import kz.yatooooo.projects.huqualities.security.Hash;
import kz.yatooooo.projects.huqualities.service.SecurityService;
import kz.yatooooo.projects.huqualities.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


@Service("userService")
public class UserServiceImplementation implements UserService{
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PhotoRepository photoRepository;
    @Autowired
    private SecurityServiceImplementation securityServiceImplementation;
    @Autowired
    private QualityServiceImplementation qualityServiceImplementation;
    @Autowired
    private UserQualityServiceImplementation userQualityServiceImplementation;
    @Autowired
    private QualityEvaluationServiceImplementation qualityEvaluationServiceImplementation;
    @Autowired
    private QualityClickServiceImplementation qualityClickServiceImplementation;

    public User getCurrentUser(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        return userRepository.findByUsername(currentPrincipalName);
    }

    public long getCurrentUserId(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        return userRepository.findByUsername(currentPrincipalName).getId();
    }

    public void saveUser(User user){
        user.setPassword(Hash.hash(user.getPassword(), user.getEmail(), "SHA-256"));
        if(user.getUsername().toLowerCase().equals("admin")){
            user.setRole("ROLE_ADMIN");
        }else{
            user.setRole("ROLE_USER");
        }
        userRepository.save(user);
    }
    @Override
    public void deleteUser(Long id) {
        User user = userRepository.findById(id);
        userRepository.delete(user);
    }

    public User findByUsername(String username){

        return userRepository.findByUsername(username);
    }

    public User findById(long id){
        return userRepository.findById(id);
    }

    public boolean isUsernameExist(String username){
        if(userRepository.findByUsername(username)!=null) return true;
        return false;
    }

    public boolean isEmailExist(String email){
        if(userRepository.findByEmail(email)!=null) return true;
        return false;
    }



    public boolean isValid(String username, String password){
        User user = null;

        if(userRepository.findByUsername(username)!=null) {
            String hashedPassword = Hash.hash(password, userRepository.findByUsername(username).getEmail(), "SHA-256");
            user = userRepository.findByUsernameAndPassword(username, hashedPassword);
        }

        if(user!=null) return true;
        return false;
    }


    public void updateFullname(String currentUsername, String name,String surname, String patronymic){
        User user = userRepository.findByUsername(currentUsername);

        if(!name.equals("") && !name.equals(user.getName())){
            user.setName(name);
        }

        if(!surname.equals("") && !surname.equals(user.getSurname())){
            user.setSurname(surname);
        }

        if(!patronymic.equals(user.getPatronymic())){
            user.setPatronymic(patronymic);
        }

        userRepository.save(user);
    }

    public void updateAccount(String currentUsername, String username,String oldPassword, String newPassword, String email){
        User user = userRepository.findByUsername(currentUsername);

        if(!username.equals("") && !username.equals(user.getUsername()) && !isUsernameExist(username)){
            user.setUsername(username);
        }

        String oldPasswordHash = Hash.hash(oldPassword, user.getEmail(), "SHA-256");
        String newPasswordHash = Hash.hash(newPassword, user.getEmail(), "SHA-256");
        if(!oldPassword.equals("") && oldPasswordHash.equals(user.getPassword()) && !newPassword.equals("") && newPassword.length()>=8 && !user.getPassword().equals(newPasswordHash)){
            user.setPassword(newPasswordHash);
        }

        if(!email.equals(user.getEmail())){
            user.setEmail(email);
        }

        userRepository.save(user);
        securityServiceImplementation.autologin(user.getUsername(), user.getPassword());
    }

    public void updateAddress(String currentUsername, String address, String
            citizenship, String phone){
        User user = userRepository.findByUsername(currentUsername);

        if(!address.equals("") && !address.equals(user.getAddress())){
            user.setAddress(address);
        }

        if(!citizenship.equals("") && !citizenship.equals(user.getCitizenship())){
            user.setCitizenship(citizenship);
        }
        if(!phone.equals("") && !phone.equals(user.getPhone())){
            user.setPhone(phone);
        }

        userRepository.save(user);
    }

    public void updateOther(String currentUsername, String maritalStatus, String gender, String birthDay) throws ParseException {
        User user = userRepository.findByUsername(currentUsername);

        if(!maritalStatus.equals("") && !maritalStatus.equals(user.getMaritalStatus())){
            user.setMaritalStatus(maritalStatus);
        }

        if(!gender.equals("") && !gender.equals(user.getGender())){
            user.setGender(gender);
        }

        if(!birthDay.equals("")){
            java.util.Date utilDate = new SimpleDateFormat("yyyy-MM-dd")
                    .parse(birthDay);
            java.sql.Date date = new java.sql.Date(utilDate.getTime());
            System.out.println(date);
            if(user.getBirthDay()==null)user.setBirthDay(date);
            else if(date.compareTo(user.getBirthDay())!=0)user.setBirthDay(date);
        }

        userRepository.save(user);
    }

    @Override
    public List<User> getUsers(String name, String surname) {
        return userRepository
                .findByNameContainingOrSurnameContaining(name, surname);
    }

    @Override
    public List<User> getUsers(String searchingWord) {
        return userRepository.getUserBySearchingWords(searchingWord);
    }
    @Override
    public List<User> getUsers(String searchingWord, String quality, String
            qualityMin, String qualityMax, String gender, String maritalStatus,
                               int ageMin, int ageMax, String citizenship) {
       List<User> all = userRepository.getUserBySearchingWords(searchingWord);
       return sortByCriteries(all, quality, qualityMin, qualityMax,gender,
               maritalStatus, ageMin, ageMax, citizenship);
    }
    @Override
    public List<User> getUsers(String name, String surname, String quality,
                               String qualityMin, String qualityMax, String gender, String maritalStatus,
                               int ageMin, int ageMax, String citizenship) {

        List<User> all = userRepository.findByNameContainingOrSurnameContaining(name, surname);
        return sortByCriteries(all, quality, qualityMin, qualityMax,gender, maritalStatus, ageMin, ageMax, citizenship);
    }
    @Override
    public List<User> getUsers(String quality,
                               String qualityMin, String qualityMax, String gender, String maritalStatus,
                               int ageMin, int ageMax, String citizenship) {

        List<User> all = userRepository.findAll();
        return sortByCriteries(all, quality, qualityMin, qualityMax,gender, maritalStatus, ageMin, ageMax, citizenship);
    }
    public List<User> sortByCriteries(List<User> all, String quality, String
            qualityMin, String qualityMax, String gender, String maritalStatus,
                                      int ageMin, int ageMax, String citizenship){
        List<User> sorted = new ArrayList<>();
        if(!quality.equals("")){
            System.out.println("IN");
            Quality q = qualityServiceImplementation.getQualityByName
                    (quality);
            List<UserQuality> userQualities = new ArrayList<>();
            for(User u: all){
                if(userQualityServiceImplementation.getByUserAndQuality(u, q) != null){
                    userQualities.add(userQualityServiceImplementation.getByUserAndQuality(u, q));
                }
            }
            if(!userQualities.isEmpty()){

                if(qualityMin!=null && qualityMax!=null && Integer.parseInt(qualityMin) != 0 && Integer.parseInt(qualityMax) != 0){
                    for(UserQuality uq: userQualities){
                        QualityEvaluation qualityEvaluation = qualityEvaluationServiceImplementation.get
                                (uq);
                        if(JavaOperations.Between(qualityEvaluation.getAverage(),
                                Integer.parseInt(qualityMin), Integer.parseInt(qualityMax))){
                            sorted.add(uq.getUser());
                        }
                    }
                }else{
                    for(UserQuality uq: userQualities){
                        sorted.add(uq.getUser());
                    }
                }
            }
        }else{
            sorted = all;
        }
        if(!sorted.isEmpty())
            sorted = sortedByGender(sorted, gender);
        if(!sorted.isEmpty())
            sorted = sortedByMaritalStatus(sorted, maritalStatus);
        if(!sorted.isEmpty())
            sorted = sortedByAge(sorted, ageMin, ageMax);
        if(!sorted.isEmpty())
            sorted =sortedByCitizenship(sorted, citizenship);

        return sorted;
    }
    public  List<User> sortedByGender(List<User> users, String  gender){
        List<User> sorted = new ArrayList<>();
        if(!gender.equals("")) {
            for (User u : users) {
                if (gender.equals(u.getGender())) {
                    sorted.add(u);
                }
            }
        }else{
            return users;
        }
        return sorted;
    }
    public  List<User> sortedByMaritalStatus(List<User> users, String maritalStatus){
        List<User> sorted = new ArrayList<>();
        if(!maritalStatus.equals("")){
            for(User u: users){
                if(maritalStatus.equals(u.getMaritalStatus())){
                    sorted.add(u);
                }
            }
        }else{
            return users;
        }
        return sorted;
    }
    public  List<User> sortedByAge(List<User> users, int minAge, int maxAge){
        List<User> sorted = new ArrayList<>();
        if(minAge != 0 && maxAge != 0){
            for(User u: users){
                if(JavaOperations.Between(u.getAge(), minAge, maxAge)){
                    sorted.add(u);
                }
            }
        }else{
            return users;
        }
        return sorted;
    }
    public  List<User> sortedByCitizenship(List<User> users, String citizenship){
        List<User> sorted = new ArrayList<>();
        if(!citizenship.equals("")){
            for(User u: users){
                if(citizenship.equals(u.getCitizenship())){
                    sorted.add(u);
                }
            }
        }else{
            return users;
        }
        return sorted;
    }

    public List<User> getAllUsers() {
        return userRepository.findAllByOrderByNameAsc();
    }

    @Override
    public List<User> getAllUsersExceptCurrent(String currentUsername) {
        User user = userRepository.findByUsername(currentUsername);
        return userRepository.findAllUserExceptCurrent(user.getId());
    }

    public User getUserById(Long id) {
        return userRepository
                .findById(id);
    }
    public void updateAll(String currentUsername, Long userId, String name,
                          String surname, String
                                  patronymic, String username, String email, String address, String
                                  maritalStatus, String gender, String birthDay, String role)
            throws
            ParseException {
        User admin =  userRepository.findByUsername(currentUsername);
        User user = getUserById(userId);

        if(!name.equals("") && !name.equals(user.getName())){
            user.setName(name);
        }

        if(!surname.equals("") && !surname.equals(user.getSurname())){
            user.setSurname(surname);
        }

        if(!patronymic.equals(user.getPatronymic())){
            user.setPatronymic(patronymic);
        }
        if(!username.equals("") && !username.equals(user.getUsername()) && !isUsernameExist(username)){
            user.setUsername(username);
        }

        if(!email.equals(user.getEmail())){
            user.setEmail(email);
        }

        if(!address.equals("") && !address.equals(user.getAddress())){
            user.setAddress(address);
        }
        if(!maritalStatus.equals("") && !maritalStatus.equals(user.getMaritalStatus())){
            user.setMaritalStatus(maritalStatus);
        }

        if(!gender.equals("") && !gender.equals(user.getGender())){
            user.setGender(gender);
        }

        if(!birthDay.equals("")){
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
            java.util.Date parsed = format.parse(birthDay);
            java.sql.Date date = new java.sql.Date(parsed.getTime());
            System.out.println(date);
            if(user.getBirthDay()==null)user.setBirthDay(date);
            else if(date.compareTo(user.getBirthDay())!=0)user.setBirthDay(date);
        }
        user.setRole(role);
        if(admin.getId() == user.getId()){
            securityServiceImplementation.autologin(user.getUsername(), user.getPassword());
        }
        userRepository.save(user);
    }

    public void uploadPhoto(String currentUsername, String url) throws Exception{
        User user =  userRepository.findByUsername(currentUsername);
        Photo p = photoRepository.findPhotoByUserEqualsAndIsAvatarEquals
                (user, 1);
        if(p != null){
            p.setIsAvatar(0);
            photoRepository.saveAndFlush(p);
        }
        Photo photo = new Photo(user, url, 1);
        if(!checkIfPhotoExist(user, url)){
            photoRepository.save(photo);
        }
    }
    @Override
    public void uploadPhoto(User user, String url) throws Exception{
        Photo p = photoRepository.findPhotoByUserEqualsAndIsAvatarEquals
                (user, 1);
        if(p != null){
            p.setIsAvatar(0);
            photoRepository.saveAndFlush(p);
        }
        Photo photo = new Photo(user, url, 1);
        if(!checkIfPhotoExist(user, url)){
            photoRepository.save(photo);
        }
    }
    public Boolean checkIfPhotoExist(User user, String url){
        Photo existingPhoto = photoRepository
                .findPhotoByUserEqualsAndUrlEquals(user, url);
        if(existingPhoto != null){
            existingPhoto.setIsAvatar(1);
            photoRepository.save(existingPhoto);
            return true;
        }
        return false;
    }
    public String findAvatarByUsername(String currentUsername){
        User user =  userRepository.findByUsername(currentUsername);

        if(photoRepository.findPhotoByUserEqualsAndIsAvatarEquals(user, 1) != null){
            return photoRepository.findPhotoByUserEqualsAndIsAvatarEquals(user, 1).getUrl();
        }
        return null;
    }
    public Photo findAvatarByUsernameObject(String currentUsername){
        User user =  userRepository.findByUsername(currentUsername);

        if(photoRepository.findPhotoByUserEqualsAndIsAvatarEquals(user, 1) != null){
            return photoRepository.findPhotoByUserEqualsAndIsAvatarEquals(user, 1);
        }
        return null;
    }
    public boolean addQuality(long id){
        Quality quality = qualityServiceImplementation.getById(id);
        User user = getCurrentUser();

        UserQuality userQuality = userQualityServiceImplementation.add(user, quality);
        QualityEvaluation qualityEvaluation = qualityEvaluationServiceImplementation.add(userQuality);

        if(userQuality!=null && qualityEvaluation!=null) return true;
        return false;
    }



    public boolean deleteQuality(long id){
        Quality quality = qualityServiceImplementation.getById(id);
        User user = getCurrentUser();

        UserQuality userQuality = userQualityServiceImplementation.getByUserAndQuality(user, quality);
        boolean qualityEvaluationCheck = qualityEvaluationServiceImplementation.delete(userQuality);
        boolean userQualityCheck = userQualityServiceImplementation.delete(user, quality);

        if(qualityEvaluationCheck && userQualityCheck) return true;
        return false;
    }


    public List<QualityClick> getMyQualitiyClicksToUser(User user){
        List<QualityClick> qualityClicks = new ArrayList<>();

        List<UserQuality> userQualities = null;
        if(userQualityServiceImplementation.getUserQualities(user)!=null){
            userQualities = userQualityServiceImplementation.getUserQualities(user);
            for (UserQuality uq:userQualities){
                if(qualityClickServiceImplementation.get(getCurrentUser(), uq)!=null){
                    qualityClicks.add(qualityClickServiceImplementation.get(getCurrentUser(), uq));
                }
            }
        }

        return qualityClicks;
    }

    public List<QualityClick> getQualitiyClickNotifications(){
        List<QualityClick> qualityClicks = new ArrayList<>();

        List<UserQuality> userQualities = null;
        if(userQualityServiceImplementation.getUserQualities(getCurrentUser())!=null){
            userQualities = userQualityServiceImplementation.getUserQualities(getCurrentUser());
            for (UserQuality uq:userQualities){
                if(qualityClickServiceImplementation.getByUserQuality(uq)!=null){
                    for(QualityClick qualityClick:qualityClickServiceImplementation.getByUserQuality(uq)){
                        qualityClicks.add(qualityClick);
                    }
                }
            }
        }

        return qualityClicks;
    }


    /**
     * get quality evaluations of certain user
     * @param user
     * @return
     */
    public List<QualityEvaluation> getQualitiyEvaluationsOfUser(User user){
        List<QualityEvaluation> qualityEvaluations = new ArrayList<>();

        List<UserQuality> userQualities = null;
        if(userQualityServiceImplementation.getUserQualities(user)!=null){
            userQualities = userQualityServiceImplementation.getUserQualities(user);
            for (UserQuality uq:userQualities){
                qualityEvaluations.add(qualityEvaluationServiceImplementation.get(uq));
            }
        }

        return qualityEvaluations;
    }
    /**
     * get qualities of certain user
     * @param user
     * @return
     */
    public List<Quality> getQualitiesOfUser(User user){
        List<Quality> qualities = new ArrayList<>();

        List<UserQuality> userQualities = null;
        if(userQualityServiceImplementation.getUserQualities(user)!=null){
            userQualities = userQualityServiceImplementation.getUserQualities(user);
            for (UserQuality uq:userQualities){
                qualities.add((uq.getQuality()));
            }
        }

        return qualities;
    }

    public List<Quality> getQualities(){
        List<Quality> qualities = new ArrayList<>();

        List<UserQuality> userQualities = null;
        if(userQualityServiceImplementation.getUserQualities(getCurrentUser())!=null){
            userQualities = userQualityServiceImplementation.getUserQualities(getCurrentUser());
            for (UserQuality uq:userQualities){
                qualities.add((uq.getQuality()));
            }
        }

        return qualities;
    }

    public List<Quality> getQualitiesWithoutMine(){
        List<Quality> qualities = new ArrayList<>();

        List<Quality> allQualities = qualityServiceImplementation.allQualities();

        List<UserQuality> userQualities = userQualityServiceImplementation.getUserQualities(getCurrentUser());
        List<Quality> temp_qualities = new ArrayList<>();

        if(userQualities!=null) {
            for (UserQuality uq : userQualities) {
                temp_qualities.add((uq.getQuality()));
            }
        }

        if(allQualities!=null && temp_qualities!=null) {
            boolean existIn = false;
            for (Quality aq : allQualities) {
                for (Quality tq : temp_qualities) {
                    if (aq == tq) {
                        existIn = true;
                        break;
                    }
                }

                if (!existIn) qualities.add(aq);
                existIn = false;
            }
        }

        return qualities;
    }

}
