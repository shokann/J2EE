package kz.yatooooo.projects.huqualities.repository;


import kz.yatooooo.projects.huqualities.model.QualityCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QualityCategoryRepository extends JpaRepository<QualityCategory, Long>{
}
