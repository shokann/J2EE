package kz.yatooooo.projects.huqualities.serviceImplementation;

import kz.yatooooo.projects.huqualities.model.Quality;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.operations.JavaOperations;
import kz.yatooooo.projects.huqualities.repository.QualityRepository;
import kz.yatooooo.projects.huqualities.service.QualityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("qualityService")
public class QualityServiceImplementation implements QualityService {
    @Autowired
    private QualityRepository qualityRepository;

    @Autowired
    private UserServiceImplementation userServiceImplementation;
    @Autowired
    private UserQualityServiceImplementation userQualityServiceImplementation;
    @Autowired
    private QualityEvaluationServiceImplementation qualityEvaluationServiceImplementation;


    public Quality getById(long id){
        Quality quality = null;
        if(qualityRepository.findById(id)!=null)
            quality = qualityRepository.findById(id);

        return quality;
    }

    @Override
    public void saveQuality(String name, String description) {
        Quality quality = new Quality();
        String qualityName = JavaOperations.getFirstLetterUppercase(name);
        quality.setName(qualityName);
        quality.setDescription(description);
        qualityRepository.save(quality);
    }

    @Override
    public void updateQuality(Long id, String name, String description) {
        Quality quality = qualityRepository.findById(id);
        if(!name.equals("") && !name.equals(quality.getName())){
            String qualityName = JavaOperations.getFirstLetterUppercase(name);
            quality.setName(qualityName);
        }
        if(!description.equals("") && !description.equals(quality.getDescription())){
            quality.setDescription(description);
        }
        qualityRepository.save(quality);
    }

    @Override
    public void deleteQuality(Long id) {
        Quality quality = qualityRepository.findById(id);
        qualityRepository.delete(quality);
    }

    @Override
    public boolean isQualityExist(String title) {
        if(qualityRepository.findByName(title) !=null) return true;
        return false;
    }
    @Override
    public Quality getQualityByName(String title) {
        Quality quality = null;
        if(qualityRepository.findByName(title)!=null)
            quality = qualityRepository.findByName(title);

        return quality;
    }

    @Override
    public List<Quality> allQualities() {
        return qualityRepository.findAll();
    }

}
