package kz.yatooooo.projects.huqualities.service;

public interface FriendService{
}
