package kz.yatooooo.projects.huqualities.repository;

import kz.yatooooo.projects.huqualities.model.QualityEvaluation;
import kz.yatooooo.projects.huqualities.model.UserQuality;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QualityEvaluationRepository extends JpaRepository<QualityEvaluation, Long> {
    QualityEvaluation findByUserQuality(UserQuality userQuality);
    void deleteByUserQuality(UserQuality userQuality);
    void removeByUserQuality(UserQuality userQuality);
}
