package kz.yatooooo.projects.huqualities.model;

import javax.persistence.*;

@Entity
public class Photo {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @ManyToOne
    @JoinColumn(name = "USER_ID", referencedColumnName = "id")
    private User user;

    @Column(name = "url", unique = true)
    private String url;

    @Column(name = "isAvatar")
    private long isAvatar;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    public Photo(){

    }
    public Photo(User user, String url, long isAvatar) {
       this.user = user;
       this.url = url;
       this.isAvatar = isAvatar;
    }

    public long getIsAvatar() {
        return isAvatar;
    }

    public void setIsAvatar(long isAvatar) {
        this.isAvatar = isAvatar;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

}
