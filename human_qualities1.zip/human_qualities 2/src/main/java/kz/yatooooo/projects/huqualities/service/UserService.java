package kz.yatooooo.projects.huqualities.service;

import kz.yatooooo.projects.huqualities.model.User;

import java.util.List;


public interface UserService {
    void saveUser(User user);
    void deleteUser(Long id);
    boolean isUsernameExist(String username);
    boolean isEmailExist(String email);
    List<User> getUsers(String name, String surname);
    List<User> getUsers(String name, String surname, String quality, String qualityMin, String qualityMax,
                        String gender, String maritalStatus, int ageMin, int ageMax, String citizenship);
    List<User> getUsers(String searchingWord);
    List<User> getUsers(String searchingWord, String quality, String qualityMin, String qualityMax,
                        String gender, String maritalStatus, int ageMin, int ageMax, String citizenship);
    List<User> getUsers(String quality, String qualityMin, String qualityMax,
                        String gender, String maritalStatus, int ageMin, int ageMax, String citizenship);
    List<User> getAllUsers();
    List<User> getAllUsersExceptCurrent(String currentUsername);
    void uploadPhoto(User user, String url)throws Exception;
}
