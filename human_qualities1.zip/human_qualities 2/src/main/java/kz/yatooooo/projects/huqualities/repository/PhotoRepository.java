package kz.yatooooo.projects.huqualities.repository;

import kz.yatooooo.projects.huqualities.model.Photo;
import kz.yatooooo.projects.huqualities.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PhotoRepository extends JpaRepository<Photo, Long> {
    Photo findPhotoByUserEqualsAndIsAvatarEquals(User u, long isAvatar);
    Photo findPhotoByUserEqualsAndUrlEquals(User u, String url);
}
