package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.serviceImplementation.QualityServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.SecurityServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.text.ParseException;

@Controller
public class HomeController {
    @Autowired
    private UserServiceImplementation userServiceImplementation;
    @Autowired
    private QualityServiceImplementation qualityServiceImplementation;

    @GetMapping("/user/page/home")
    public ModelAndView displayAsUser(){
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        if(userServiceImplementation.findByUsername(currentUsername)!=null)
            modelAndView.addObject("user", userServiceImplementation.findByUsername(currentUsername));

        if(userServiceImplementation.findAvatarByUsername(currentUsername)!=null)
            modelAndView.addObject("userAvatar", userServiceImplementation.findAvatarByUsername(currentUsername));

        if(userServiceImplementation.getQualities().size()>0)
            modelAndView.addObject("qualities", userServiceImplementation.getQualities());

        if(userServiceImplementation.getQualitiyEvaluationsOfUser(userServiceImplementation.findByUsername(currentUsername)).size()>0)
            modelAndView.addObject("qualityevaluations", userServiceImplementation.getQualitiyEvaluationsOfUser(userServiceImplementation.findByUsername(currentUsername)));

        if(userServiceImplementation.getMyQualitiyClicksToUser(userServiceImplementation.findByUsername(currentUsername)).size()>0)
            modelAndView.addObject("qualityclicks", userServiceImplementation.getMyQualitiyClicksToUser(userServiceImplementation.findByUsername(currentUsername)));

        modelAndView.setViewName("user/home");
        return modelAndView;
    }

    @GetMapping("/admin/page/home")
    public ModelAndView displayAsAdmin(){
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        modelAndView.addObject("user", userServiceImplementation.findByUsername(currentPrincipalName));

        modelAndView.setViewName("admin/home");
        return modelAndView;
    }
}
