package kz.yatooooo.projects.huqualities.serviceImplementation;

import kz.yatooooo.projects.huqualities.model.Quality;
import kz.yatooooo.projects.huqualities.model.QualityEvaluation;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.model.UserQuality;
import kz.yatooooo.projects.huqualities.repository.QualityEvaluationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class QualityEvaluationServiceImplementation {
    @Autowired
    private QualityEvaluationRepository qualityEvaluationRepository;

    public QualityEvaluation add(UserQuality userQuality){
        if(userQuality!=null){
            if(!isExist(userQuality)){
                QualityEvaluation qualityEvaluation = new QualityEvaluation(userQuality);
                qualityEvaluationRepository.save(qualityEvaluation);
                return qualityEvaluationRepository.findByUserQuality(userQuality);
            }
        }

        return null;
    }

    public QualityEvaluation changeIfIsAlreadyClicked(UserQuality userQuality, double value, double preValue){
        if(userQuality!=null){
            if(isExist(userQuality)){
                QualityEvaluation qualityEvaluation = qualityEvaluationRepository.findByUserQuality(userQuality);
                qualityEvaluation.setSum(qualityEvaluation.getSum()-preValue+value);
                qualityEvaluation.setAverage(qualityEvaluation.getSum()/qualityEvaluation.getCount());
                qualityEvaluationRepository.save(qualityEvaluation);
                return qualityEvaluationRepository.findByUserQuality(userQuality);
            }
        }

        return null;
    }

    public QualityEvaluation changeIfIsNotAlreadyClicked(UserQuality userQuality, double value){
        if(userQuality!=null){
            if(isExist(userQuality)){
                QualityEvaluation qualityEvaluation = qualityEvaluationRepository.findByUserQuality(userQuality);
                qualityEvaluation.setSum(qualityEvaluation.getSum()+value);
                qualityEvaluation.setCount(qualityEvaluation.getCount()+1);
                qualityEvaluation.setAverage(qualityEvaluation.getSum()/qualityEvaluation.getCount());
                qualityEvaluationRepository.save(qualityEvaluation);
                return qualityEvaluationRepository.findByUserQuality(userQuality);
            }
        }

        return null;
    }


    public boolean delete(UserQuality userQuality){
        if(userQuality==null) return false;
        if(!isExist(userQuality)) return false;

        qualityEvaluationRepository.deleteByUserQuality(userQuality);
        return true;
    }


    public boolean isExist(UserQuality userQuality) {
        if(qualityEvaluationRepository.findByUserQuality(userQuality)!=null) return true;
        return false;
    }

    public QualityEvaluation get(UserQuality userQuality){
        if(qualityEvaluationRepository.findByUserQuality(userQuality)!=null)
            return qualityEvaluationRepository.findByUserQuality(userQuality);

        return null;
    }
}
