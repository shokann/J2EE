package kz.yatooooo.projects.huqualities.operations;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JavaOperations {
    public static int getCountOfWordsInString(String s){
        String trim = s.trim();
        if (trim.isEmpty())
            return 0;
        return trim.split("\\s+").length; // separate string around spaces
    }
    public static String getCurrentTimeInStringFormat(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
        Date date = new Date();
        String my_str = dateFormat.format(date);
        String my_new_str = my_str.replace("/", "_");
        my_new_str = my_new_str.replace(":", "_");
        my_new_str = my_new_str.replace(" ", "_");
        return my_new_str;
    }
    public static java.sql.Date getCurrentDate(){
        long millis=System.currentTimeMillis();
        java.sql.Date date=new java.sql.Date(millis);
        return date;
    }

    public static String getFirstLetterUppercase(String str){
        if(str != null){
            return str.substring(0, 1).toUpperCase() + str.substring(1);
        }
        return null;
    }
    public static boolean Between(double value, int min,int max){
        return value > min && value < max;
    }
    public static boolean Between(int value, int min,int max){
        return value > min && value < max;
    }
}
