package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.model.QualityClick;
import kz.yatooooo.projects.huqualities.repository.FriendRepository;
import kz.yatooooo.projects.huqualities.repository.UserRepository;
import kz.yatooooo.projects.huqualities.serviceImplementation.FriendServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.QualityClickServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProfileController {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private FriendServiceImplementation friendServiceImplementation;
    @Autowired
    private UserServiceImplementation userServiceImplementation;
    @Autowired
    private QualityClickServiceImplementation qualityClickServiceImplementation;

    @GetMapping("/user/page/profile/id/{id}")
    public ModelAndView displayAsUser(Model model, @PathVariable("id")long id){
        ModelAndView modelAndView = new ModelAndView();

        if(friendServiceImplementation.isFriend(id)==true)
            modelAndView.addObject("isfriend", friendServiceImplementation.isFriend(id));



        if(userRepository.findById(id)!=null)
        modelAndView.addObject("user", userRepository.findById(id));

        String username = null;
        if(userRepository.findById(id).getUsername()!=null){
            username = userRepository.findById(id).getUsername();
            modelAndView.addObject("userAvatar", userServiceImplementation.findAvatarByUsername(username));
        }

        if(userServiceImplementation.getQualitiyEvaluationsOfUser(userRepository.findById(id)).size()>0)
            modelAndView.addObject("qualityevaluations", userServiceImplementation.getQualitiyEvaluationsOfUser(userRepository.findById(id)));

        if(userServiceImplementation.getMyQualitiyClicksToUser(userRepository.findById(id)).size()>0)
            modelAndView.addObject("qualityclicks", userServiceImplementation.getMyQualitiyClicksToUser(userRepository.findById(id)));

        modelAndView.setViewName("user/profile");
        return modelAndView;
    }


    @GetMapping("/admin/page/profile/id/{id}")
    public String displayAsAdmin(Model model, @PathVariable("id")long ID){
        model.addAttribute("user", userRepository.findById(ID));
        return "admin/profile";
    }
}
