package kz.yatooooo.projects.huqualities.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "USER_QUALITY")
//@IdClass(UserQualityId.class)
public class UserQuality implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "USER_QUALITY_ID")
    private long id;

//    @Id айдишки ли они
    @ManyToOne
    @JoinColumn(name = "USER_ID", referencedColumnName = "ID")
    private User user;

//    @Id
    @ManyToOne
    @JoinColumn(name = "QUALITY_ID", referencedColumnName = "ID")
    private Quality quality;

    @OneToMany(mappedBy = "userQuality")
    private List<QualityClick> qualityClicks = new ArrayList<>();

    @OneToMany(mappedBy = "userQuality")
    private List<QualityEvaluation> qualityEvaluations = new ArrayList<>();

    public UserQuality() {

    }

    public UserQuality(User user, Quality quality) {
        this.user = user;
        this.quality = quality;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Quality getQuality() {
        return quality;
    }

    public void setQuality(Quality quality) {
        this.quality = quality;
    }
}
