package kz.yatooooo.projects.huqualities.serviceImplementation;

import kz.yatooooo.projects.huqualities.model.*;
import kz.yatooooo.projects.huqualities.repository.QualityClickRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QualityClickServiceImplementation {

    @Autowired
    private QualityClickRepository qualityClickRepository;
    @Autowired
    private QualityEvaluationServiceImplementation qualityEvaluationServiceImplementation;

    public QualityClick get(User user, UserQuality userQuality){
        if(qualityClickRepository.findByUserAndUserQuality(user,userQuality)!=null)
            return qualityClickRepository.findByUserAndUserQuality(user,userQuality);
        return null;
    }

    public List<QualityClick> getByUserQuality(UserQuality userQuality){
        if(qualityClickRepository.findByUserQuality(userQuality).size()>0)
            return qualityClickRepository.findByUserQuality(userQuality);
        return null;
    }

    public QualityClick add(User user, UserQuality userQuality, double value){
        if(user!=null && userQuality!=null) {
            if (isExist(user, userQuality))
                return change(user, userQuality, value);
            else{
                QualityClick qualityClick = new QualityClick();
                qualityClick.setUser(user);
                qualityClick.setUserQuality(userQuality);
                qualityClick.setValue(value);

                qualityClickRepository.save(qualityClick);
                if(isExist(user, userQuality))
                    qualityEvaluationServiceImplementation.changeIfIsNotAlreadyClicked(userQuality, value);
                    return qualityClickRepository.findByUserAndUserQuality(user, userQuality);
            }
        }

        return null;
    }

    public QualityClick change(User user, UserQuality userQuality, double value){
        double preValue = 0.0;

        if(user!=null && userQuality!=null){
            QualityClick qualityClick = qualityClickRepository.findByUserAndUserQuality(user, userQuality);
            preValue = qualityClick.getValue();
            qualityClick.setValue(value);
            qualityClickRepository.save(qualityClick);
            if(isExist(user, userQuality))
                qualityEvaluationServiceImplementation.changeIfIsAlreadyClicked(userQuality, value,preValue);
                return qualityClickRepository.findByUserAndUserQuality(user, userQuality);
        }
        return null;
    }

    public boolean isExist(User user, UserQuality userQuality){
        if(qualityClickRepository.findByUserAndUserQuality(user,userQuality)!=null)
            return true;
        return false;
    }
}
