package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.model.*;
import kz.yatooooo.projects.huqualities.serviceImplementation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class QualityController {

    @Autowired
    private UserQualityServiceImplementation userQualityServiceImplementation;
    @Autowired
    private QualityServiceImplementation qualityServiceImplementation;
    @Autowired
    private UserServiceImplementation userServiceImplementation;
    @Autowired
    private QualityClickServiceImplementation qualityClickServiceImplementation;
    @Autowired
    private QualityEvaluationServiceImplementation qualityEvaluationServiceImplementation;


    @GetMapping("/user/page/qualities")
    public ModelAndView displayQuality() {
        ModelAndView modelAndView = new ModelAndView();

        modelAndView.addObject("myqualities", userServiceImplementation.getQualities());
        modelAndView.addObject("notmyqualities", userServiceImplementation.getQualitiesWithoutMine());

        modelAndView.setViewName("user/qualities");
        return modelAndView;
    }
    @PostMapping("/user/page/qualities/add")
    public ModelAndView addQuality(@RequestParam(value = "id", required = false)long id) {
        ModelAndView modelAndView = new ModelAndView();

        userServiceImplementation.addQuality(id);

        modelAndView.setViewName("redirect:/user/page/qualities");
        return modelAndView;
    }

    @PostMapping("/user/page/qualities/delete")
    public ModelAndView deleteQuality(@RequestParam(value = "id", required = false)long id) {
        ModelAndView modelAndView = new ModelAndView();

        userServiceImplementation.deleteQuality(id);

        modelAndView.setViewName("redirect:/user/page/qualities");
        return modelAndView;
    }

    @PostMapping("/user/page/qualities/evaluate")
    public ModelAndView evaluateQuality(@RequestParam(value = "user_quality_id", required = false)long user_quality_id,
                                        @RequestParam(value = "rating", required = false)double value) {
        ModelAndView modelAndView = new ModelAndView();

        System.out.println("Evaluation rating value " + value);
        User currentUser = userServiceImplementation.getCurrentUser();
        UserQuality userQuality = userQualityServiceImplementation.getById(user_quality_id);
        QualityClick qualityClick = qualityClickServiceImplementation.add(currentUser, userQuality, value);


        modelAndView.setViewName("redirect:/user/page/profile/id/"+userQuality.getUser().getId());
        return modelAndView;
    }

    @GetMapping("/admin/page/quality")
    public ModelAndView display(@ModelAttribute("message") final String
                                        message) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("admin/quality");
        if(!message.equals("") && !message.isEmpty()){
            if(message.equals("success")){
                modelAndView.addObject("message", "Quality successfully " +
                        "created!");
            }else{
                modelAndView.addObject("message", "Quality not created! " +
                        "Because of this quality already exist.");
            }
        }

        return modelAndView;
    }

    @PostMapping("/admin/page/quality/save")
    public ModelAndView qualitySave(@RequestParam(value = "name", required =
            false)String name,
                                    @RequestParam(value = "description", required = false) String description){
        ModelAndView modelAndView = new ModelAndView();
        if(!qualityServiceImplementation.isQualityExist(name)){
            qualityServiceImplementation.saveQuality(name, description);
            modelAndView.addObject("message", "success");
        }else{
            modelAndView.addObject("message", "fail");
        }
        modelAndView.setViewName("redirect:/admin/page/quality");
        return modelAndView;
    }
    @PostMapping("/admin/page/qualities/update")
    public ModelAndView qualitiesUpdate(@RequestParam(value = "id", required = false)long id,
                                        @RequestParam(value = "name", required = false) String name,
                                        @RequestParam(value = "description", required = false) String description) {
        ModelAndView modelAndView = new ModelAndView();
        qualityServiceImplementation.updateQuality(id, name, description);

        modelAndView.setViewName("redirect:/admin/page/qualities");
        return modelAndView;
    }
    @PostMapping("/admin/page/qualities/delete")
    public ModelAndView qualitiesDelete(@RequestParam(value = "id", required =
            false)long id) {
        ModelAndView modelAndView = new ModelAndView();
        qualityServiceImplementation.deleteQuality(id);

        modelAndView.setViewName("redirect:/admin/page/qualities");
        return modelAndView;
    }
    @GetMapping("/admin/page/qualities")
    public ModelAndView displayQualities() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("admin/qualities");
        modelAndView.addObject("qualities", qualityServiceImplementation.allQualities());
        return modelAndView;
    }


    @GetMapping("/admin/page/user/qualities")
    public ModelAndView displayUserQualities() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("admin/userQualities");
        return modelAndView;
    }
}
