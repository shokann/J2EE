package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.text.ParseException;

@Controller
public class SettingsController {
    @Autowired
    private UserServiceImplementation userServiceImplementation;

    @GetMapping("/user/page/settings")
    public ModelAndView displayAsUser(){
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();
        modelAndView.addObject("user", userServiceImplementation.findByUsername(currentPrincipalUsername));

        modelAndView.setViewName("user/settings");
        return modelAndView;
    }


    @PostMapping("/user/update/fullname")
    public ModelAndView updateFullnameAsUser(@RequestParam(value = "name", required = false)String name, @RequestParam(value = "surname", required = false) String surname, @RequestParam(value = "patronymic", required = false) String patronymic){
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();
        userServiceImplementation.updateFullname(currentPrincipalUsername, name, surname, patronymic);

        modelAndView.setViewName("redirect:/user/page/settings");
        return modelAndView;
    }

    @PostMapping("/user/update/account")
    public ModelAndView updateAccountAsUser(@RequestParam(value = "username", required = false)String username, @RequestParam(value = "oldpassword", required = false) String oldPassword, @RequestParam(value = "newpassword", required = false) String newPassword, @RequestParam(value = "email", required = false) String email){
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();
        userServiceImplementation.updateAccount(currentPrincipalUsername, username, oldPassword, newPassword, email);

        modelAndView.setViewName("redirect:/user/page/settings");
        return modelAndView;
    }

    @PostMapping("/user/update/address")
    public ModelAndView updateAddressAsUser(@RequestParam(value = "address", required = false)String address,
                                            @RequestParam(value = "citizenship", required = false) String citizenship,
                                              @RequestParam(value = "phone", required = false) String phone){
        ModelAndView modelAndView = new ModelAndView();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();
        userServiceImplementation.updateAddress(currentPrincipalUsername,
                address, citizenship, phone);

        modelAndView.setViewName("redirect:/user/page/settings");
        return modelAndView;
    }

    @PostMapping("/user/update/other")
    public ModelAndView updateOtherAsUser(@RequestParam(value = "marital_status", required = false)String maritalStatus, @RequestParam(value = "gender", required = false) String gender, @RequestParam(value = "birth_date", required = false)String birthDay) throws ParseException {
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();

        userServiceImplementation.updateOther(currentPrincipalUsername, maritalStatus, gender, birthDay);

        modelAndView.setViewName("redirect:/user/page/settings");
        return modelAndView;
    }


    @GetMapping("/admin/page/settings")
    public ModelAndView displayAsAdmin(){
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();
        modelAndView.addObject("user", userServiceImplementation.findByUsername(currentPrincipalUsername));

        modelAndView.setViewName("admin/settings");
        return modelAndView;
    }


    @PostMapping("/admin/update/fullname")
    public ModelAndView updateFullnameAsAdmin(@RequestParam(value = "name", required = false)String name, @RequestParam(value = "surname", required = false) String surname, @RequestParam(value = "patronymic", required = false) String patronymic){
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();
        userServiceImplementation.updateFullname(currentPrincipalUsername, name, surname, patronymic);

        modelAndView.setViewName("redirect:/admin/page/settings");
        return modelAndView;
    }

    @PostMapping("/admin/update/account")
    public ModelAndView updateAccountAsAdmin(@RequestParam(value = "username", required = false)String username, @RequestParam(value = "oldpassword", required = false) String oldPassword, @RequestParam(value = "newpassword", required = false) String newPassword, @RequestParam(value = "email", required = false) String email){
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();
        userServiceImplementation.updateAccount(currentPrincipalUsername, username, oldPassword, newPassword, email);

        modelAndView.setViewName("redirect:/admin/page/settings");
        return modelAndView;
    }

    @PostMapping("/admin/update/address")
    public ModelAndView updateAddressAsAdmin(@RequestParam(value = "address", required = false)String address,
                                             @RequestParam(value = "citizenship", required = false) String citizenship,
                                             @RequestParam(value = "phone", required = false) String phone){
        ModelAndView modelAndView = new ModelAndView();

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();
        userServiceImplementation.updateAddress(currentPrincipalUsername,
                address, citizenship, phone);

        modelAndView.setViewName("redirect:/admin/page/settings");
        return modelAndView;
    }

    @PostMapping("/admin/update/other")
    public ModelAndView updateOtherAsAdmin(@RequestParam(value = "marital_status", required = false)String maritalStatus,
                                           @RequestParam(value = "gender", required = false) String gender,
                                           @RequestParam(value = "birth_date", required = false)String birthDay) throws ParseException {
        ModelAndView modelAndView = new ModelAndView();
        System.out.println("Birth date: " + birthDay);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalUsername = authentication.getName();

        userServiceImplementation.updateOther(currentPrincipalUsername, maritalStatus, gender, birthDay);

        modelAndView.setViewName("redirect:/admin/page/settings");
        return modelAndView;
    }
}
