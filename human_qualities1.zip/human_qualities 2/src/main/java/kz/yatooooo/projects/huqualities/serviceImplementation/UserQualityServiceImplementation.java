package kz.yatooooo.projects.huqualities.serviceImplementation;

import kz.yatooooo.projects.huqualities.model.Quality;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.model.UserQuality;
import kz.yatooooo.projects.huqualities.repository.QualityRepository;
import kz.yatooooo.projects.huqualities.repository.UserQualityRepository;
import kz.yatooooo.projects.huqualities.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class UserQualityServiceImplementation {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private QualityRepository qualityRepository;
    @Autowired
    private UserQualityRepository userQualityRepository;

    public UserQuality add(User user, Quality quality){
        if(user!=null && quality!=null){
            if(!isExist(user,quality)){
                UserQuality userQuality = new UserQuality(user, quality);
                userQualityRepository.save(userQuality);
                return userQualityRepository.findByUserAndQuality(user, quality);
            }
        }

        return null;
    }

    public boolean delete(User user, Quality quality){
        if(user==null && quality==null) return false;
        if(!isExist(user,quality)) return false;

        userQualityRepository.deleteByUserAndQuality(user, quality);

        return true;
    }

    public UserQuality getByUserAndQuality(User user, Quality quality){
        if(user!=null && quality!=null){
            if(isExist(user,quality)){
                return userQualityRepository.findByUserAndQuality(user, quality);
            }
        }

        return null;
    }

    public UserQuality getById(long id){
        if(userQualityRepository.findById(id)!=null){
            return userQualityRepository.findById(id);
        }
        return null;
    }

    public boolean isExist(User u, Quality q) {
        if(userQualityRepository.findByUserAndQuality(u, q)!=null) return true;
        return false;
    }

    public List<UserQuality> getUserQualities(User user){
        List<UserQuality> userQualities = null;

        if(userQualityRepository.findAllByUser(user).size()>0){
            userQualities = userQualityRepository.findAllByUser(user);
        }

        return userQualities;
    }
}
