package kz.yatooooo.projects.huqualities.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AccessDeniedController {

    @GetMapping("/403")
    public ModelAndView display(){
        return new ModelAndView("403");
    }
}
