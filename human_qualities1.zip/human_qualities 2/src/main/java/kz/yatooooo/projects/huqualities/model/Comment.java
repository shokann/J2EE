package kz.yatooooo.projects.huqualities.model;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @ManyToOne
    @JoinColumn(name = "listener", referencedColumnName = "id")
    private User listener;

    @ManyToOne
    @JoinColumn(name = "commentator", referencedColumnName = "id")
    private User comentator;

    @NotEmpty(message = "Comment ")
    private String message;

    public Comment() {
    }

    public Comment(User listener, User comentator, String message) {
        this.listener = listener;
        this.comentator = comentator;
        this.message = message;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getListener() {
        return listener;
    }

    public void setListener(User listener) {
        this.listener = listener;
    }

    public User getComentator() {
        return comentator;
    }

    public void setComentator(User comentator) {
        this.comentator = comentator;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
