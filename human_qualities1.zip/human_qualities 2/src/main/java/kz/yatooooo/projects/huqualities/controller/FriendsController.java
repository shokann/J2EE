package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.model.Photo;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.serviceImplementation.FriendServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.persistence.JoinColumn;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

@Controller
public class FriendsController {
    @Autowired
    private FriendServiceImplementation friendServiceImplementation;
    @Autowired
    private UserServiceImplementation userServiceImplementation;
    @GetMapping("/user/page/friends")
    public ModelAndView displayAsUser(){
        ModelAndView modelAndView = new ModelAndView();

        List<User> friends = friendServiceImplementation.getAllFriends();
        List<Photo> avatars =  new ArrayList<>();
        for(User u: friends){
            avatars.add(userServiceImplementation.findAvatarByUsernameObject(u.getUsername()));
        }

        if(!avatars.isEmpty()){
            modelAndView.addObject("friendAvatar", avatars);
        }
        
        if(friends.size()>0){
            modelAndView.addObject("friends", friends);
        }

        modelAndView.setViewName("user/friends");
        return modelAndView;
    }

    @GetMapping("/user/page/friend/see")
    public ModelAndView friendSeeAsUser(@RequestParam(value = "id", required = false) long id){
        return new ModelAndView("redirect:/user/page/profile/id/"+id);
    }

    @PostMapping("/user/page/friend/delete")
    public ModelAndView friendDeleteAsUser(@RequestParam(value = "id", required = false) long id){
        System.out.println("delete ID :: " + id);
        friendServiceImplementation.deleteFromFriends(id);
        return new ModelAndView("redirect:/user/page/friends");
    }

    @PostMapping("/user/page/friend/add")
    public ModelAndView friendAddAsUser(@RequestParam(value = "id", required = false) long host) {

        friendServiceImplementation.send(host);
        return new ModelAndView("redirect:/user/page/friends");
    }
}
