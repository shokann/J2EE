package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.operations.JavaOperations;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


@Controller
public class PhotoController {
    @Autowired
    private UserServiceImplementation userServiceImplementation;

    @PostMapping("/user/upload/photo")
    public ModelAndView upload(@RequestParam("avatar") MultipartFile file){
        ModelAndView modelAndView = new ModelAndView();
        System.out.println("____________________________");

        if (file.isEmpty()) {
            //modelAndView.setViewName("redirect:/page/home");
            System.out.println("File is empty");
        }

        try {
            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            String[] getTypeOfFile = file.getContentType().split("/");
            if(!getTypeOfFile[0].equals("image")){
                modelAndView.addObject("message", "type");
                modelAndView.setViewName("redirect:/user/page/error");
            }else if(file.getSize() > 2097152) {
                modelAndView.addObject("message", "size");
                modelAndView.setViewName("redirect:/user/page/error");
            }else{
                System.out.println("Size: " + file.getSize());

                String fileName = JavaOperations.getCurrentTimeInStringFormat
                        () + "_" + DigestUtils.shaHex(file
                        .getOriginalFilename
                        ())+ "." + getTypeOfFile[1];
                Path path = Paths.get("src/main/resources/static/images/avatars/" + fileName);
                Files.write(path, bytes);

                Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                String currentPrincipalUsername = authentication.getName();
                userServiceImplementation.uploadPhoto
                        (currentPrincipalUsername, fileName);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        modelAndView.setViewName("redirect:/user/page/home");
        return modelAndView;
    }
}
