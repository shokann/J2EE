package kz.yatooooo.projects.huqualities.repository;

import kz.yatooooo.projects.huqualities.model.Quality;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QualityRepository extends JpaRepository<Quality,Long>{
    Quality findByName(String name);
    Quality findById(Long id);

}
