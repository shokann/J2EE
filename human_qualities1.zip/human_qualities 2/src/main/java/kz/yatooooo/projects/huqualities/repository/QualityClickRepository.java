package kz.yatooooo.projects.huqualities.repository;

import kz.yatooooo.projects.huqualities.model.Quality;
import kz.yatooooo.projects.huqualities.model.QualityClick;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.model.UserQuality;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QualityClickRepository extends JpaRepository<QualityClick,Long>{
    QualityClick findByUserAndUserQuality(User user, UserQuality userQuality);
    List<QualityClick> findByUserQuality(UserQuality userQuality);
}
