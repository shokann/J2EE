package kz.yatooooo.projects.huqualities.bootstrap;

import kz.yatooooo.projects.huqualities.model.*;
import kz.yatooooo.projects.huqualities.repository.*;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class DefBootstrap implements ApplicationListener<ContextRefreshedEvent>{
    private UserRepository userRepository;
    private QualityRepository qualityRepository;
    private UserQualityRepository userQualityRepository;
    private QualityClickRepository qualityClickRepository;
    private QualityEvaluationRepository qualityEvaluationRepository;

    public DefBootstrap(UserRepository userRepository, QualityRepository qualityRepository, UserQualityRepository userQualityRepository, QualityClickRepository qualityClickRepository, QualityEvaluationRepository qualityEvaluationRepository) {
        this.userRepository = userRepository;
        this.qualityRepository = qualityRepository;
        this.userQualityRepository = userQualityRepository;
        this.qualityClickRepository = qualityClickRepository;
        this.qualityEvaluationRepository = qualityEvaluationRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        System.out.println("===onApplicationEvent===");
        initData();
    }

    public void initData(){
//        System.out.println("===iniData===");
//
//        Quality quality_1 = new Quality("Loyal", "Loyal");
//        User user_1 = new User("Akezhan", "Abilgazy", "Nurgalym", new Date(), "Almaty c. Zhumalyeva 28", "not married", "kazakh",  null);
//
//        UserQuality userQuality = new UserQuality();
//        userQuality.setUser(user_1);
//        userQuality.setQuality(quality_1);
//
//        QualityClick qualityClick = new QualityClick(userQuality, user_1, 123);
//        QualityEvaluation qualityEvaluation = new QualityEvaluation(userQuality, 100, 1,100/1);
//
//        qualityRepository.save(quality_1);
//        userRepository.save(user_1);
//        userQualityRepository.save(userQuality);
//        qualityClickRepository.save(qualityClick);
//        qualityEvaluationRepository.save(qualityEvaluation);
    }
}
