package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.model.Photo;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.operations.JavaOperations;
import kz.yatooooo.projects.huqualities.serviceImplementation.FriendServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.QualityServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
public class SearchController {
    @Autowired
    private UserServiceImplementation userServiceImplementation;

    @Autowired
    private FriendServiceImplementation friendServiceImplementation;
    @Autowired
    private QualityServiceImplementation qualityServiceImplementation;

    public SearchController() {

    }
    @GetMapping(value="/user/page/extended/search")
    public ModelAndView extendedSearchAsUserGet() {
        ModelAndView modelAndView = new ModelAndView();

        modelAndView.addObject("allqualities", qualityServiceImplementation.allQualities());
        modelAndView.setViewName("user/search");
        return modelAndView;
    }
    @GetMapping(value="/admin/page/extended/search")
    public ModelAndView extendedSearchAsAdminGet() {
        ModelAndView modelAndView = new ModelAndView();

        modelAndView.addObject("allqualities", qualityServiceImplementation.allQualities());
        modelAndView.setViewName("admin/search");
        return modelAndView;
    }
    @PostMapping(value="/user/page/extended/search")
    public ModelAndView extendedSearchAsUserPost(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "quality", required = false) String quality,
            @RequestParam(value = "quality_value_min", required = false) String quality_value_min,
            @RequestParam(value = "quality_value_max", required = false) String quality_value_max,
            @RequestParam(value = "gender", required = false) String gender,
            @RequestParam(value = "marital_status", required = false) String marital_status,
            @RequestParam(value = "age_value_min", required = false) int age_value_min,
            @RequestParam(value = "age_value_max", required = false) int age_value_max,
            @RequestParam(value = "citizenship", required = false) String citizenship) {
        ModelAndView modelAndView = new ModelAndView();

        int count = JavaOperations.getCountOfWordsInString(search);

        if(count == 0){

            List<User> all = userServiceImplementation.getUsers(quality, quality_value_min, quality_value_max,
                    gender, marital_status, age_value_min, age_value_max, citizenship);
            User search_me = null;
            List<User> search_friends = new ArrayList<>();
            List<User> search_users = new ArrayList<>();
            List<Photo> avatars =  new ArrayList<>();

            for(User u:all){
                avatars.add(userServiceImplementation.findAvatarByUsernameObject(u.getUsername()));
                if(u==userServiceImplementation.findById(userServiceImplementation.getCurrentUserId())){
                    search_me = userServiceImplementation.findById(userServiceImplementation.getCurrentUserId());
                    continue;
                }

                if(friendServiceImplementation.isFriend(u.getId())) {
                    search_friends.add(u);
                    continue;
                }

                search_users.add(u);
            }

            if(!avatars.isEmpty()){
                modelAndView.addObject("friendAvatar", avatars);
            }
            modelAndView.addObject("search_me", search_me);
            modelAndView.addObject("search_friends", search_friends);
            modelAndView.addObject("search_users", search_users);
        }else if(count > 2){
            modelAndView.addObject("message", "Not found!");
        }else if(count == 1){

            List<User> all = userServiceImplementation.getUsers(search, quality, quality_value_min, quality_value_max,
                    gender, marital_status, age_value_min, age_value_max, citizenship);
            User search_me = null;
            List<User> search_friends = new ArrayList<>();
            List<User> search_users = new ArrayList<>();
            List<Photo> avatars =  new ArrayList<>();

            for(User u:all){
                avatars.add(userServiceImplementation.findAvatarByUsernameObject(u.getUsername()));
                if(u==userServiceImplementation.findById(userServiceImplementation.getCurrentUserId())){
                    search_me = userServiceImplementation.findById(userServiceImplementation.getCurrentUserId());
                    continue;
                }

                if(friendServiceImplementation.isFriend(u.getId())) {
                    search_friends.add(u);
                    continue;
                }
                search_users.add(u);
            }

            if(!avatars.isEmpty()){
                modelAndView.addObject("friendAvatar", avatars);
            }
            modelAndView.addObject("search_me", search_me);
            modelAndView.addObject("search_friends", search_friends);
            modelAndView.addObject("search_users", search_users);

        }else if(count == 2){

            String[] parts = search.split(" ");

            List<User> all = userServiceImplementation.getUsers(parts[0],
                    parts[1], quality, quality_value_min, quality_value_max,
                    gender, marital_status, age_value_min, age_value_max, citizenship);
            User search_me = null;
            List<User> search_friends = new ArrayList<>();
            List<User> search_users = new ArrayList<>();
            List<Photo> avatars =  new ArrayList<>();
            for(User u:all){
                avatars.add(userServiceImplementation.findAvatarByUsernameObject(u.getUsername()));
                if(u==userServiceImplementation.findById(userServiceImplementation.getCurrentUserId())){
                    search_me = userServiceImplementation.findById(userServiceImplementation.getCurrentUserId());
                    continue;
                }

                if(friendServiceImplementation.isFriend(u.getId())) {
                    search_friends.add(u);
                    continue;
                }

                search_users.add(u);
            }

            if(!avatars.isEmpty()){
                modelAndView.addObject("friendAvatar", avatars);
            }
            modelAndView.addObject("search_me", search_me);
            modelAndView.addObject("search_friends", search_friends);
            modelAndView.addObject("search_users", search_users);
        }

        modelAndView.setViewName("user/friends");
        return modelAndView;
    }
    @PostMapping(value="/admin/page/extended/search")
    public ModelAndView extendedSearchAsAdminGet(
             @RequestParam(value = "search", required = false) String search,
             @RequestParam(value = "quality", required = false) String quality,
             @RequestParam(value = "quality_value_min", required = false) String quality_value_min,
             @RequestParam(value = "quality_value_max", required = false) String quality_value_max,
             @RequestParam(value = "gender", required = false) String gender,
             @RequestParam(value = "marital_status", required = false) String marital_status,
             @RequestParam(value = "age_value_min", required = false) int age_value_min,
             @RequestParam(value = "age_value_max", required = false) int age_value_max,
             @RequestParam(value = "citizenship", required = false) String citizenship) {
        ModelAndView modelAndView = new ModelAndView();
        List<Photo> avatars =  new ArrayList<>();
        int count = JavaOperations.getCountOfWordsInString(search);
        if(count == 0 ){
            List<User> all = userServiceImplementation
                    .getUsers( quality, quality_value_min, quality_value_max,
                            gender, marital_status, age_value_min, age_value_max, citizenship);
            modelAndView.addObject("users", all);
            for(User u: all){
                avatars.add(userServiceImplementation.findAvatarByUsernameObject(u.getUsername()));
            }
            if(!avatars.isEmpty()){
                modelAndView.addObject("friendAvatar", avatars);
            }
        }else if(count > 2){
            modelAndView.addObject("message", "Not found!");
        }else if(count == 1){
            List<User> all = userServiceImplementation
                    .getUsers(search, quality, quality_value_min, quality_value_max,
                            gender, marital_status, age_value_min, age_value_max, citizenship);
            modelAndView.addObject("users", all);
            for(User u: all){
                avatars.add(userServiceImplementation.findAvatarByUsernameObject(u.getUsername()));
            }
            if(!avatars.isEmpty()){
                modelAndView.addObject("friendAvatar", avatars);
            }
        }else if(count == 2){
            String[] parts = search.split(" ");
            List<User> all = userServiceImplementation
                    .getUsers(parts[0], parts[1], quality, quality_value_min, quality_value_max,
                            gender, marital_status, age_value_min, age_value_max, citizenship);
            modelAndView.addObject("users",all);
            for(User u: all){
                avatars.add(userServiceImplementation.findAvatarByUsernameObject(u.getUsername()));
            }
            if(!avatars.isEmpty()){
                modelAndView.addObject("friendAvatar", avatars);
            }
        }

        modelAndView.setViewName("admin/friends");
        return modelAndView;
    }
    @GetMapping(value="/user/page/search")
    public ModelAndView findFriendAsUser(@RequestParam(value = "search", required = false) String search) {
        ModelAndView modelAndView = new ModelAndView();

        int count = JavaOperations.getCountOfWordsInString(search);

        if(count == 0 ){
            modelAndView.setViewName("redirect:/user/page/extended/search");
        }else if(count > 2){
            modelAndView.addObject("message", "Not found!");
            modelAndView.setViewName("user/friends");
        }else if(count == 1){

            List<User> all = userServiceImplementation.getUsers(search);
            User search_me = null;
            List<User> search_friends = new ArrayList<>();
            List<User> search_users = new ArrayList<>();
            List<Photo> avatars =  new ArrayList<>();

            for(User u:all){
                avatars.add(userServiceImplementation.findAvatarByUsernameObject(u.getUsername()));
                if(u==userServiceImplementation.findById(userServiceImplementation.getCurrentUserId())){
                    search_me = userServiceImplementation.findById(userServiceImplementation.getCurrentUserId());
                    continue;
                }

                if(friendServiceImplementation.isFriend(u.getId())) {
                    search_friends.add(u);
                    continue;
                }
                search_users.add(u);
            }
            if(!avatars.isEmpty()){
                modelAndView.addObject("friendAvatar", avatars);
            }

            modelAndView.addObject("search_me", search_me);
            modelAndView.addObject("search_friends", search_friends);
            modelAndView.addObject("search_users", search_users);
            modelAndView.setViewName("user/friends");
        }else if(count == 2){

            String[] parts = search.split(" ");

            List<User> all = userServiceImplementation.getUsers(parts[0], parts[1]);
            User search_me = null;
            List<User> search_friends = new ArrayList<>();
            List<User> search_users = new ArrayList<>();
            List<Photo> avatars =  new ArrayList<>();
            for(User u:all){
                avatars.add(userServiceImplementation.findAvatarByUsernameObject(u.getUsername()));
                if(u==userServiceImplementation.findById(userServiceImplementation.getCurrentUserId())){
                    search_me = userServiceImplementation.findById(userServiceImplementation.getCurrentUserId());
                    continue;
                }

                if(friendServiceImplementation.isFriend(u.getId())) {
                    search_friends.add(u);
                    continue;
                }

                search_users.add(u);
            }
            if(!avatars.isEmpty()){
                modelAndView.addObject("friendAvatar", avatars);
            }
            modelAndView.addObject("search_me", search_me);
            modelAndView.addObject("search_friends", search_friends);
            modelAndView.addObject("search_users", search_users);
            modelAndView.setViewName("user/friends");
        }


        return modelAndView;
    }

    @GetMapping(value="/admin/page/search")
    public ModelAndView findFriendAsAdmin(@RequestParam(value = "search",
            required = false) String search) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("admin/friends");

        System.out.println("modalandview: " + search);
        int count = JavaOperations.getCountOfWordsInString(search);
        if(count == 0 ){
            modelAndView.setViewName("redirect:/user/page/extended/search");
        }else if(count > 2){
            modelAndView.addObject("message", "Not found!");
            modelAndView.setViewName("admin/friends");
        }else if(count == 1){
            System.out.println("modalandview: " + search);
            modelAndView.addObject("users", userServiceImplementation
                    .getUsers(search));
            modelAndView.setViewName("admin/friends");
        }else if(count == 2){
            String[] parts = search.split(" ");
            modelAndView.addObject("users", userServiceImplementation
                    .getUsers(parts[0], parts[1]));
            modelAndView.setViewName("admin/friends");
        }

        return modelAndView;
    }

}
