package kz.yatooooo.projects.huqualities.security;

import java.nio.charset.Charset;
import java.security.MessageDigest;

public class Hash {

    public static String hash(String unecryptedPassword, String salt, String type){
        String encryptedPassword = "";
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(type);
            messageDigest.update((unecryptedPassword + salt).getBytes(Charset.forName("UTF-8")));
            byte messageDigestsInBytes[] = messageDigest.digest();
            StringBuffer hexString = new StringBuffer();

            for (int i=0; i<messageDigestsInBytes.length; i++)
            {
                String hex = Integer.toHexString(0xFF & messageDigestsInBytes[i]);

                if(hex.length()==1)
                {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            if(hexString!=null && !hexString.equals("")) encryptedPassword = hexString.toString();
        }catch (Exception e){
            e.printStackTrace();
        }

        return encryptedPassword;
    }
}
