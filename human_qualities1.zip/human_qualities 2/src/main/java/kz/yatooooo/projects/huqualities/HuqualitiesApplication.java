package kz.yatooooo.projects.huqualities;

import kz.yatooooo.projects.huqualities.bootstrap.DefBootstrap;
import kz.yatooooo.projects.huqualities.repository.UserRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HuqualitiesApplication {

	public static void main(String[] args){
		SpringApplication.run(HuqualitiesApplication.class, args);
	}
}
