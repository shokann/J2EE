package kz.yatooooo.projects.huqualities.repository;

import kz.yatooooo.projects.huqualities.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserRepository extends JpaRepository<User, Long>{
    User findById(long id);
    User findByUsername(String username);
    User findByEmail(String email);
    User findByUsernameAndPassword(String username, String password);
    List<User> findAllByOrderByNameAsc();
    @Query("select u from User u where u.id != ?1")
    List<User> findAllUserExceptCurrent(long id);
    List<User> findByNameContainingOrSurnameContaining(String firstName, String lastName);
    @Query("select u from User u where upper(u.name) like concat('%', " +
            "upper(?1), '%') or upper(u.surname) like concat('%', upper(?1), '%')  ")
    List<User> getUserBySearchingWords(String searchingWord);


}
