package kz.yatooooo.projects.huqualities.controller;

import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.repository.UserRepository;
import kz.yatooooo.projects.huqualities.security.Hash;
import kz.yatooooo.projects.huqualities.service.SecurityService;
import kz.yatooooo.projects.huqualities.serviceImplementation.SecurityServiceImplementation;
import kz.yatooooo.projects.huqualities.serviceImplementation.UserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collection;

@Controller
public class LoginController {
    @Autowired
    private UserServiceImplementation userServiceImplementation;
    @Autowired
    private SecurityServiceImplementation securityServiceImplementation;

    public LoginController() {

    }

    @PostMapping("/login")
    public ModelAndView login(@RequestParam(value = "username", required = false) String username,@RequestParam(value = "password", required = false) String password){
        ModelAndView modelAndView = new ModelAndView();

        if(userServiceImplementation.isValid(username, password)){
            securityServiceImplementation.login(username, password);
            String role = securityServiceImplementation.getCurrentUserRole();

            if(role.equals("admin")){
                modelAndView.setViewName("redirect:/admin/page/home");
            }else if(role.equals("user")){
                modelAndView.setViewName("redirect:/user/page/home");
            }else{
                modelAndView.setViewName("redirect:/");
            }
        }else{
            modelAndView.setViewName("redirect:/");
        }

        return modelAndView;
    }

    @GetMapping(value="/logout")
    public ModelAndView logoutPage (HttpServletRequest request, HttpServletResponse
            response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return new ModelAndView("redirect:/");
    }
}
