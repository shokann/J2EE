package kz.yatooooo.projects.huqualities.serviceImplementation;

import kz.yatooooo.projects.huqualities.model.Comment;
import kz.yatooooo.projects.huqualities.model.User;
import kz.yatooooo.projects.huqualities.repository.CommentRepository;
import org.springframework.stereotype.Service;

@Service
public class CommentServiceImplementation {

    private CommentRepository commentRepository;

    public Comment add(User listener, User commentator, String message){
        Comment comment = null;

        if(listener!=null && commentator!=null && message!=null && !message.equals("")){
            comment = new Comment(listener, commentator, message);
            commentRepository.save(comment);
        }

        return comment;
    }

    public Comment change(long id, String message){
        Comment comment = null;

        if(message!=null) {
            comment = commentRepository.findOne(id);
            comment.setMessage(message);
            commentRepository.save(comment);
        }

        return comment;
    }

    public boolean delete(long id){
        if(commentRepository.findOne(id)!=null){
            commentRepository.delete(id);
            return true;
        }

        return false;
    }



}
