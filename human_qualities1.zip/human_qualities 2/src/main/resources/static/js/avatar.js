$(document).ready(function(){
    $("#fileid").change(function(){
        var input = $(this)[0];
        if (input.files && input.files[0]) {

            var reader = new FileReader();

            reader.onload = function (e) {
                $('#avatar_in_model')
                    .attr('src', e.target.result)
                    .width(253+"px")
                    .height(300+"px");
                $('#user_avatar_in_model')
                    .attr('src', e.target.result)
                    .width(253+"px")
                    .height(300+"px");
            };

            reader.readAsDataURL(input.files[0]);
        }
    });
});