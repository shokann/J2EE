
// $("#country_selector").countrySelect({
//   //defaultCountry: "jp",
//   //onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
//   preferredCountries: ['ca', 'gb', 'us']
// });

$('#fname').focus(function () {
    $("#errorName").text("");
});
$('#fname').focusout(function () {
    var name =  $("#fname").val();
    if(name === ""){
        $("#errorName").text("*please provide your name");
    }
});

$('#surname').focus(function () {
    $("#errorSurname").text("");
});
$('#surname').focusout(function () {
    var name =  $("#surname").val();
    if(name === ""){
        $("#errorSurname").text("*please provide your surname");
    }
});

$('#email').focus(function () {
    $("#errorEmail").text("");
});
$('#email').focusout(function () {
    var name =  $("#email").val();
    if(name === ""){
        $("#errorEmail").text("*please provide your e-mail");
    }else if(!validateEmail(name)){
        $("#errorEmail").text("*please provide a valid e-mail");
    }
});


$('#username').focus(function () {
    $("#errorUsername").text("");
});
$('#username').focusout(function () {
    var name =  $("#username").val();
    if(name === ""){
        $("#errorUsername").text("*please provide your username");
    }
});

$('#password').focus(function () {
    $("#errorPassword").text("");
});
$('#password').focusout(function () {
    var name =  $("#password").val();
    if(name === ""){
        $("#errorPassword").text("*please provide your password");
    }else if(name.length < 8){
        $("#errorPassword").text("*your password must have at least 8 characters");
    }
});
$('#repassword').focus(function () {
    $("#errorRepassword").text("");
});
$('#repassword').focusout(function () {
    var name =  $("#repassword").val();
    if(name === ""){
        $("#errorRepassword").text("*password not confirm");
    }
});

function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}