$("main").click(function(){
      document.getElementById("user").style.visibility = "hidden";
      document.getElementById("user").style.zIndex = "-1";
      document.getElementById("user").style.opacity = "0";
});
$("#right").click(function(){
      document.getElementById("user").style.visibility = "visible";
      document.getElementById("user").style.zIndex = "999";
      document.getElementById("user").style.opacity = "1";
      document.getElementById("user").style.right = "40px";
      document.getElementById("user").style.top = "65px";
      document.getElementById("user").style.width = "300px";
      document.getElementById("user").style.height = "365px";
      document.getElementById("user").style.color = "#111";
      document.getElementById("user").style.backgroundColor = "#fff";
      document.getElementById("user").style.boxShadow = " 0 2px 2px 0 rgba(0,0,0,.14), 0 3px 1px -2px rgba(0,0,0,.2), 0 1px 5px 0 rgba(0,0,0,.12)";
      document.getElementById("user").style.transition  = "transform .6s cubic-bezier(.4,0,.2,1),opacity .3s cubic-bezier(.4,0,.2,1)";

});