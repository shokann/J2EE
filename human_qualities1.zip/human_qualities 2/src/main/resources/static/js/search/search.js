const qualitySelect = document.getElementById('quality-select');
const ratingControlMin = document.getElementById('rating-control-min');
const ratingControlMax = document.getElementById('rating-control-max');

const ageControlMin = document.getElementById('age-control-min');
const ageControlMax = document.getElementById('age-control-max');

qualitySelect.addEventListener('change', (e) => {
    let quality = e.target.value;
    if(quality == ""){
        ratingControlMin.disabled = true;
        ratingControlMax.disabled = true;
    }else{
        ratingControlMin.disabled = false;
        ratingControlMax.disabled = false;
    }
});
ratingControlMin.addEventListener('change', (e) => {
    let minValue = e.target.value;
    let options = ratingControlMax.childNodes;
    for(var i = 0; i < options.length; i++) {

        if(options[i].value <= minValue && options[i].value != 10){

            options[i].disabled = true;
        }else{
            options[i].disabled = false;
        }
    }
});
ratingControlMax.addEventListener('change', (e) => {
    let maxValue = e.target.value;
    let options = ratingControlMin.childNodes;
    for(var i = 0; i < options.length; i++) {
        if(options[i].value >= maxValue || options[i].value == 10){
            options[i].disabled = true;
        }else{
            options[i].disabled = false;
        }
    }
});

ageControlMin.addEventListener('change', (e) => {
    let minAge = e.target.value;
    let options = ageControlMax.childNodes;
    for(var i = 1; i < options.length; i+=2) {
        var boo = Boolean((options[i].value-minAge) <= 0)
        if(boo){
            options[i].disabled = true;
        }else{
            options[i].disabled = false;
        }
    }
});
ageControlMax.addEventListener('change', (e) => {
    let maxAge = e.target.value;
    let options = ageControlMin.childNodes;
    for(var i = 1; i < options.length; i+=2) {
        var boo = Boolean((maxAge - options[i].value) <= 0)
        if(boo){
            options[i].disabled = true;
        }else{
            options[i].disabled = false;
        }
    }
});
